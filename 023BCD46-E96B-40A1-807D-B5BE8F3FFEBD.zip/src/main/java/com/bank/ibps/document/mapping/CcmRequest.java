package com.bank.ibps.document.mapping;

public record CcmRequest(String json) {
}
