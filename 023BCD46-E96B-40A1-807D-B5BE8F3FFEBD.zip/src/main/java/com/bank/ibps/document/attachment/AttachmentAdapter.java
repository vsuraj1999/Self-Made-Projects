package com.bank.ibps.document.attachment;

public interface AttachmentAdapter {
    AttachmentResult attach(String workitemId, String documentType,
                            byte[] pdfBytes, String idempotencyKey);
}
