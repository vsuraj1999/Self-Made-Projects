package com.bank.ibps.document.config;

public record DocumentConfig(
        String configId,
        int version,
        boolean enabled,
        String processKey,
        String wfdPath,
        String documentType,
        String ccmOperation,
        String requestMappingId,
        String responseFormat,
        String attachmentPolicy) {
}
