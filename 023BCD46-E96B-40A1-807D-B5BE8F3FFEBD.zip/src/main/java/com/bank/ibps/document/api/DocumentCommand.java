package com.bank.ibps.document.api;

public record DocumentCommand(
        String processKey,
        String wfdPath,
        String documentType,
        String workitemId,
        String correlationId) {
}
