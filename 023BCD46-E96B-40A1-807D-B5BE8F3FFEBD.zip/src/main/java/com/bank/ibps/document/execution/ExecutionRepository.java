package com.bank.ibps.document.execution;

import java.util.Optional;

public interface ExecutionRepository {
    Optional<ExecutionRecord> findByIdempotencyKey(String key);
    boolean tryClaim(ExecutionRecord record);
    void update(ExecutionRecord record);
}
