package com.bank.ibps.document.execution;

public record ExecutionRecord(
        String idempotencyKey,
        String workitemId,
        String documentType,
        String status,
        int retryCount,
        String documentId,
        String safeErrorCode) {
}
