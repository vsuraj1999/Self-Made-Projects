package com.bank.ibps.document.attachment;

public record AttachmentResult(String documentId, boolean confirmed) {
}
