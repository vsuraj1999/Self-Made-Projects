package com.bank.ibps.document.orchestrator;

import com.bank.ibps.document.api.DocumentCommand;
import com.bank.ibps.document.api.DocumentResult;

/**
 * Use-case boundary. Wire verified implementations using the target runtime's
 * supported dependency-injection/lookup mechanism.
 */
public interface DocumentGenerationOrchestrator {
    DocumentResult generate(DocumentCommand command);
}
