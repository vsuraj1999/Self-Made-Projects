package com.bank.ibps.document.ccm;

import com.bank.ibps.document.config.DocumentConfig;
import com.bank.ibps.document.mapping.CcmRequest;

public interface CcmClient {
    CcmResponse generate(CcmRequest request, DocumentConfig config);
}
