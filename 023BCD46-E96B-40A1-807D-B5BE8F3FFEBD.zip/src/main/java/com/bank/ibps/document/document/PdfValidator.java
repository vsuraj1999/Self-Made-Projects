package com.bank.ibps.document.document;

import com.bank.ibps.document.ccm.CcmResponse;

public interface PdfValidator {
    byte[] validateAndDecode(CcmResponse response, long maxPdfSizeBytes);
}
