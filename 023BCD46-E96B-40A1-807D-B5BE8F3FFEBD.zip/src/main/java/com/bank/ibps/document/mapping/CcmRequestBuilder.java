package com.bank.ibps.document.mapping;

import com.bank.ibps.document.config.DocumentConfig;

public interface CcmRequestBuilder {
    CcmRequest build(DocumentConfig config, WorkitemContext context);
}
