package com.bank.ibps.document.api;

public record DocumentResult(
        String status,
        String documentId,
        String correlationId) {

    public static DocumentResult success(String documentId, String correlationId) {
        return new DocumentResult("SUCCESS", documentId, correlationId);
    }

    public static DocumentResult skipped(String correlationId) {
        return new DocumentResult("SKIPPED", null, correlationId);
    }
}
