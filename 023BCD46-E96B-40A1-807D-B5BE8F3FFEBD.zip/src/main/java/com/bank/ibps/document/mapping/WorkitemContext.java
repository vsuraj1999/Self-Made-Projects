package com.bank.ibps.document.mapping;

import java.util.Map;

public record WorkitemContext(String workitemId, Map<String, Object> fields) {
}
