package com.bank.ibps.document.config;

public interface DocumentConfigResolver {
    DocumentConfig resolve(String processKey, String wfdPath, String documentType);
}
