package com.bank.ibps.document.ccm;

public record CcmResponse(int httpStatus, String base64Pdf, String ccmCorrelationId) {
}
