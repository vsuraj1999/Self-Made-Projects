package com.bank.ibps.document.api;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DocumentResultTest {
    @Test
    void successResultContainsDocumentIdAndCorrelationId() {
        DocumentResult result = DocumentResult.success("doc-123", "corr-456");
        assertEquals("SUCCESS", result.status());
        assertEquals("doc-123", result.documentId());
        assertEquals("corr-456", result.correlationId());
    }

    @Test
    void skippedIsNotFailure() {
        DocumentResult result = DocumentResult.skipped("corr-456");
        assertEquals("SKIPPED", result.status());
        assertNull(result.documentId());
    }
}
