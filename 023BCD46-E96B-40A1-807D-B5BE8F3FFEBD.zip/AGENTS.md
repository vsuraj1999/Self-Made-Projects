# Coding-agent instructions

You are implementing a production-minded, configuration-driven iBPS–CCM PDF orchestrator.

## Non-negotiable architecture
- Keep business orchestration independent of CCM HTTP details and iBPS/OmniDocs API details.
- Use interfaces for `CcmClient`, `AttachmentAdapter`, `DocumentConfigRepository`, and `ExecutionRepository`.
- Do not invent iBPS/OmniDocs SDK classes, method names, or endpoint contracts. Ask for the actual API documentation or isolate unknowns behind TODO adapter methods.
- New document onboarding must normally require configuration only: process key, WFD path, document type, request mapping, response mapping/policy, and attachment policy.
- Configuration must be validated before activation and versioned.
- No arbitrary code execution, SQL, JavaScript, or unrestricted expressions in mappings. Use allow-listed operations only.
- Never log secrets, full customer payloads, Base64, or PDF bytes.

## Reliability
- Use stable idempotency keys and enforce uniqueness in the persistent store; do not rely on in-memory maps or locks.
- Do not retry every exception. Classify errors and retry only safe transient failures.
- Treat timeout-after-success as an ambiguous outcome; reconcile before repeating generation or attachment.
- Do not hold database transactions open during network calls.
- Bound HTTP response size and concurrency.
- Separate generation state from attachment state where needed.

## Engineering workflow
1. Inspect the current repository before editing.
2. Write/maintain a short plan and identify unknown external contracts.
3. Implement in small, compiling increments.
4. Add unit tests for each behavior and negative path.
5. Run `mvn test` and report actual results; never claim tests passed unless run.
6. Keep Java version and dependency choices compatible with the target WebSphere/iBPS runtime.
7. Add TODO markers for environment-specific integrations rather than fabricating implementations.

## Definition of done
- Configuration errors fail fast with safe diagnostics.
- Mapping supports required fields, constants, nested objects and approved transformations.
- CCM response handling validates HTTP status, payload presence, Base64, size, and PDF signature.
- Duplicate commands cannot silently create duplicate attachments.
- Failures are observable through correlation IDs and sanitized status/error fields.
- Unit tests cover success, malformed config, missing required fields, invalid Base64, non-PDF bytes, CCM timeout, attachment failure and duplicate requests.
