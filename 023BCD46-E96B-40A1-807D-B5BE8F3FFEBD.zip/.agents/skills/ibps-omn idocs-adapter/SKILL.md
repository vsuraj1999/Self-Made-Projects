---
name: ibps-omnidocs-adapter
description: Implement the vendor-specific iBPS workitem and OmniDocs attachment adapter using verified SDK/API documentation.
---

# iBPS / OmniDocs adapter skill

## Before implementation
Confirm the installed iBPS and OmniDocs versions, supported Java runtime, official SDK/API documentation, authentication/authorization, document-type identifiers, attachment/version semantics, and whether the API is idempotent.

## Rules
- Implement only the verified API contract.
- Keep all vendor SDK imports inside this adapter package.
- Verify the target workitem and permissions before attaching.
- Use the required document type and metadata.
- Return a document/attachment identifier when the API supplies one.
- Treat timeouts as ambiguous until attachment state is checked.
- Do not claim an attachment succeeded until the API response or follow-up lookup confirms it.
- Add adapter contract tests using approved test doubles or vendor test environment.
- Do not fake a production implementation with guessed class names.
