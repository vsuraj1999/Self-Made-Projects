---
name: testing-and-delivery
description: Build a test strategy and deliver the orchestrator in compiling, incremental steps with verified test results.
---

# Testing and delivery skill

## Unit tests
Cover:
- configuration lookup, versioning, invalid/ambiguous configuration
- mapping of simple and nested payloads
- required field missing and unsupported transformation
- valid Base64 PDF, invalid Base64, empty response and size limit
- CCM 4xx, 429, 5xx, timeout and malformed response
- attachment success, failure and ambiguous timeout
- duplicate invocation and concurrent claims
- skipped optional document versus failed generation

## Integration tests
- Use a mock CCM server for request/response contract tests.
- Use an adapter contract test for OmniDocs.
- Do not call real banking systems from unit tests.
- Keep secrets and customer data out of fixtures.

## Delivery
- Compile and test after each meaningful change.
- Report exact commands and actual outcomes.
- Check dependency and bytecode compatibility with the target WebSphere runtime.
- Provide deployment notes, rollback plan, configuration examples and open questions.
