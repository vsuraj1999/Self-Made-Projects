---
name: architecture
description: Design and evolve the iBPS–CCM document orchestrator without coupling business logic to vendor APIs. Use for architecture, package structure, interfaces, and deployment decisions.
---

# Architecture skill

## Goal
Build a reusable Java orchestrator hosted in the existing iBPS/WebSphere environment unless verified constraints justify a separate service.

## Required boundaries
- `orchestrator`: coordinates the use case only.
- `config`: resolves versioned process/document definitions.
- `mapping`: maps workitem context to a CCM request using a safe declarative schema.
- `ccm`: REST client, response parsing and CCM error classification.
- `document`: Base64 decoding and PDF validation.
- `attachment`: adapter around the actual approved OmniDocs/iBPS API.
- `execution`: idempotency, durable execution states and recovery.
- `audit`: sanitized events and correlation IDs.

## Rules
- Do not introduce Kafka, a new microservice, or a new framework without a documented need.
- Do not let CCM DTOs leak into the iBPS attachment layer.
- Do not let vendor-specific API types leak into orchestration interfaces.
- Separate configuration, request mapping, response parsing, and attachment policy.
- Record assumptions and unresolved vendor-contract questions in `docs/OPEN_QUESTIONS.md`.
- Prefer small interfaces and testable units over a generic framework.
