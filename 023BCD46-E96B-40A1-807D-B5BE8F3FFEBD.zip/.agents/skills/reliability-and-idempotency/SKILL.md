---
name: reliability-and-idempotency
description: Design durable execution tracking, duplicate prevention, retries and recovery for document generation and attachment.
---

# Reliability and idempotency skill

## State model
Use durable states such as:
`PENDING -> GENERATING -> GENERATED -> ATTACHING -> SUCCESS`
with terminal/operational alternatives such as `SKIPPED`, `FAILED_PERMANENT`, and `RETRYABLE_FAILURE`.

If generated PDF bytes are not persisted, document that a failed attachment may require regeneration. Prefer persisting metadata and a safe recovery reference, not necessarily the PDF itself.

## Idempotency
- Define a stable key using workitem ID, document type and a business-defined document/version intent.
- Enforce uniqueness in the database.
- Define whether re-generation creates a new version, replaces a document, or returns the previous result.
- Use atomic claim/compare-and-set semantics across cluster nodes.
- Do not use a local `HashMap` as the source of truth.

## Retry policy
- Retry only classified transient errors with bounded exponential backoff and jitter.
- Do not blindly retry non-idempotent CCM calls after a timeout.
- Reconcile attachment status before retrying after ambiguous attachment outcomes.
- Keep network calls outside database transactions.
- Add operational reconciliation for executions stuck in intermediate states.
