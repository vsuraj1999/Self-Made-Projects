---
name: configuration-and-mapping
description: Create versioned document configuration and safe request mappings so new processes/documents can be onboarded without Java changes.
---

# Configuration and mapping skill

## Inputs per document definition
- process key
- exact WFD path
- document type
- enabled/version
- request mapping ID/version
- CCM operation/template identifier
- response mapping or response format
- attachment policy
- timeout/size overrides only when required

## Mapping capabilities
Support only explicit, allow-listed operations:
- read a field from workitem context
- assign a constant
- read approved invocation context
- create nested JSON objects/arrays
- required-field validation
- explicitly supported date/number/string formatting

## Validation
- Reject unknown source types, missing required fields, duplicate target paths, unsupported transformations, malformed JSON and ambiguous active definitions.
- Do not use unrestricted SpEL, JavaScript, SQL, reflection, or dynamically loaded classes.
- Separate environment settings/secrets from document definitions.
- Version mappings and retain the version used by every execution.
- Validate before activation and support rollback to a prior version.

## Deliverables
When changing configuration, update examples and tests. Demonstrate that a second document with a different request shape works without changing orchestrator code.
