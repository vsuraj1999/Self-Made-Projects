---
name: ccm-rest-integration
description: Implement and test the CCM REST client and Base64 PDF response processing. Use when working on HTTP, authentication, payloads, timeouts, or response parsing.
---

# CCM REST integration skill

## First confirm
Obtain the real CCM API contract: endpoint, HTTP method, authentication, headers, request schema, success/error response schemas, correlation/idempotency support, maximum response size, and timeout expectations. Never invent these.

## Implementation
- Keep transport code inside `CcmClient` implementation.
- Use explicit connection and response timeouts.
- Enforce response-size limits before buffering large bodies where feasible.
- Classify HTTP/network errors into permanent, retryable, and ambiguous outcomes.
- Parse the response schema explicitly; reject missing or malformed Base64.
- Decode Base64 and validate PDF signature (`%PDF-`) plus reasonable size. Signature check alone is not complete PDF validation.
- Never log request bodies, customer fields, Base64, or PDF bytes.
- Propagate correlation IDs and capture safe response metadata.
- Retry only when safe; a timeout can occur after CCM has completed generation.
