# Open questions before production implementation

1. What Java version is supported by the target iBPS/WebSphere environment?
2. What exact iBPS and OmniDocs versions and attachment API are available?
3. What are the CCM endpoint, authentication method, request/response examples and error schema?
4. Does CCM support request idempotency or document retrieval by correlation ID?
5. Does OmniDocs attachment support idempotency, lookup, replace/version, and return a document ID?
6. What is the actual WFD path format and how is process identity obtained from a workitem?
7. Where should configuration live: governed DB or version-controlled files?
8. What are typical and maximum PDF sizes, peak concurrent calls and response-time percentiles?
9. What is the expected behavior for re-generation: no-op, replace, or create a new version?
10. Can CCM generation and attachment be synchronous within workflow time limits?
11. What audit retention, access-control and customer-data policies apply?
