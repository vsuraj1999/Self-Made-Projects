# Architecture

## Decision
Start as a reusable Java module deployed with the existing iBPS/WebSphere application. Do not introduce a separate service or broker until latency, load, deployment ownership, or fault isolation justifies it.

## Flow
1. iBPS supplies workitem ID, process key, WFD path and document type.
2. Validate command and resolve an enabled, versioned configuration.
3. Atomically claim an execution using a persistent idempotency key.
4. Load the workitem context using the verified iBPS mechanism.
5. Build a CCM request using the selected mapping.
6. Call CCM with explicit timeout and safe error classification.
7. Decode and validate the returned PDF.
8. Attach using the verified OmniDocs API.
9. Persist attachment reference and final status.

## Key decisions
- Request mapping is configuration, not process-specific Java branches.
- Vendor APIs are isolated behind interfaces.
- Network calls do not occur inside long database transactions.
- Retries are stage-specific and safe only when operation semantics are known.
- Configuration is versioned and audited.
- `SKIPPED` is distinct from `FAILED`.
