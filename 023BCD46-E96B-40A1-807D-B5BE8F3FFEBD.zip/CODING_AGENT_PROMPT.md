# Prompt for your coding agent

Read `AGENTS.md` and every skill under `.agents/skills/` before changing code. Treat these files as project requirements.

Build the iBPS–CCM Document Generation Orchestrator incrementally.

## Context
- Deployment target: Java component inside the existing iBPS/WebSphere environment.
- CCM is called through REST.
- Request structures differ by document type.
- CCM returns a Base64-encoded PDF.
- PDF is attached to the correct workitem through the approved OmniDocs API.
- New documents should be onboarded through configuration wherever possible.
- Daily volume is approximately 100–5,000 PDFs; actual peak concurrency and document sizes must be measured.

## First task: inspect and plan
1. Inspect the repository and summarize what already exists.
2. List missing facts from `docs/OPEN_QUESTIONS.md`.
3. Do not guess iBPS/OmniDocs API signatures, CCM schema, authentication or Java compatibility.
4. Propose a phased plan and identify what can be implemented/tested without external API details.

## Build order
1. Implement strict configuration models, parser, resolver and validation.
2. Implement a safe mapping engine for workitem fields, constants, nested objects and allow-listed transforms.
3. Implement CCM client abstraction and HTTP implementation only after the real API contract is supplied.
4. Implement Base64/PDF validation and size limits.
5. Implement the attachment adapter against verified OmniDocs documentation.
6. Implement persistent execution tracking and database-enforced idempotency.
7. Add unit, contract and integration tests.
8. Add deployment/rollback documentation for the actual WebSphere/iBPS version.

## Constraints
- Do not add a framework, broker or microservice without justification.
- Keep secrets and customer payloads out of logs and source control.
- Do not use an in-memory map as durable execution state.
- Do not blindly retry non-idempotent operations.
- Run tests and report exact outcomes; never claim unrun tests passed.
- If a vendor-specific detail is missing, leave a clear interface/TODO and ask for the exact documentation rather than inventing it.

Begin by producing the plan and the list of integration facts needed from the user. Do not implement vendor-specific adapters until those facts are confirmed.
