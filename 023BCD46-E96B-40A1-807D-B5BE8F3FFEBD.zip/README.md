# iBPS–CCM Document Generation Orchestrator

A starter project for a configuration-driven Java component that:
1. Resolves process/WFD/document configuration.
2. Builds document-specific CCM REST requests from declarative mappings.
3. Calls CCM and validates Base64 PDF responses.
4. Attaches PDFs through an adapter for the approved iBPS/OmniDocs API.
5. Records execution state and supports safe retries/idempotency.

## Important integration boundary

This repository is an integration-ready scaffold, **not a drop-in iBPS deployment**. Real iBPS and OmniDocs API signatures, authentication, request/response schemas, supported Java version, and WebSphere constraints must be confirmed from your environment before implementing the production adapters.

## Project layout

- `AGENTS.md`: instructions for coding agents.
- `.agents/skills/`: portable skill files for agentic coding tools.
- `src/main/java/...`: Java architecture scaffold.
- `src/main/resources/application.yml`: non-secret default configuration.
- `src/main/resources/document-config/`: example document and request mappings.
- `src/test/java/...`: test starting points.
- `docs/`: architecture and implementation decisions.

## Build

Requires a JDK compatible with the configured Maven compiler release and Maven.

```bash
mvn test
mvn package
```

The scaffold uses Java 17 as a development default. If your iBPS/WebSphere runtime requires Java 8 or 11, change the compiler target and replace any incompatible APIs/dependencies before deployment.

## Recommended implementation order

1. Confirm runtime Java version, WebSphere version, iBPS version, CCM contract and OmniDocs attachment API.
2. Implement configuration parsing and validation.
3. Implement request mapping with allow-listed transformations.
4. Implement CCM HTTP client, timeout handling and response validation.
5. Implement the real OmniDocs attachment adapter.
6. Add a persistent execution repository and atomic idempotency constraints.
7. Add integration tests against approved test environments.
8. Validate deployment packaging and classloader/dependency compatibility.

## Security

- Never commit credentials, customer data, PDFs or Base64 payloads.
- Do not log full request bodies or document contents.
- Treat configuration as controlled production data: validate, version, audit and approve changes.
